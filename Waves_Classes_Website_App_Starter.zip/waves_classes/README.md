# Waves Classes — website + installable app starter

This package contains a responsive website/PWA starter for Waves Classes. It is designed to be usable on desktop and mobile and can be installed on supported Android browsers as an app-like PWA.

## Included
- Responsive Waves Classes dashboard
- Demo login role selector: Admin, Teacher, Staff, Parent
- Student registration with student and parent phone fields left blank until you add them
- WhatsApp/SMS consent checkboxes
- Manual attendance screen
- Fee balance and offline payment recording
- Parent messaging setup placeholder
- Reports summary
- PWA manifest, service worker and app icon

## Important status
This is a **front-end demo**, not a production-ready student management system. Demo data is stored in the browser's local storage on that device. It does not yet authenticate real users, sync records between devices, or securely isolate parent/teacher accounts. Do not enter real student information until the Supabase backend, authentication, database policies, backups and privacy controls are deployed and tested.

The WhatsApp/SMS provider integration is not live. Add the official number later in the secure provider setup; never put provider API keys in browser code.

## Run locally
Open `index.html` in a browser. For PWA install and service-worker support, serve the folder over HTTPS (or localhost), for example:
`python -m http.server 8000`

## Website deployment
Deploy the folder to an HTTPS static host (for example, institute-owned hosting). Connect a custom domain after the institute owner approves it.

## Android / Play Store
The PWA can be installed from a supported browser. Publishing a Play Store listing requires an Android package (commonly a Trusted Web Activity wrapper or a native Flutter/Android client), signing, store listing, privacy policy, data-safety declarations and Play Console access. An adult institute representative must manage the developer account and legal/business declarations. This ZIP is not an APK and has not been submitted to Google Play.

## Next production steps
1. Create and configure the Supabase project.
2. Deploy the database schema, authentication and row-level security.
3. Replace the demo data layer with authenticated cloud queries.
4. Implement per-parent child linking and teacher assignment permissions.
5. Finish QR attendance, custom fee installments and scheduled reminders.
6. Deploy the notification Edge Function and configure Meta WhatsApp Cloud API + MSG91 securely.
7. Security test using test accounts before importing student data.
